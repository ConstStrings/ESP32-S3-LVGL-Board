
Simple Buttons
""""""""""""""""

.. lv_example:: widgets/btn/lv_example_btn_1
  :language: c


Styling buttons
""""""""""""""""

.. lv_example:: widgets/btn/lv_example_btn_2
  :language: c

Gummy button
""""""""""""""""

.. lv_example:: widgets/btn/lv_example_btn_3
  :language: c

